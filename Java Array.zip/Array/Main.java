import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> color1=new ArrayList<String>();
		color1.add("Red");
		color1.add("Green");
		color1.add("Orange");
		color1.add("White");
		color1.add("Black");
		
		List<String> color2=new ArrayList<String>();
		color2.add("Red");
		color2.add("Pink");
		color2.add("Green");
		color2.add("Yellow");
		color2.add("Blue");
		
		System.out.println("------  Before Compare -----");
		System.out.println("Color 1: "+ color1);
		System.out.println("Color 1: "+ color2);
		
		System.out.println("------  Let's Compare -----");
		for (String element : color2) {
			String output = color1.contains(element)? "Yes":"NO";
			System.out.println(element + " is existing in color1:"+ output);
		}
		System.out.println("-----  End Compare -----");
		
		
	}

}
