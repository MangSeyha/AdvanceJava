import java.util.*;
public class Exercise3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>C1= new ArrayList<String>();
		C1.add("Red");
		C1.add("Green");
		C1.add("Black");
		C1.add("White");
		C1.add("Pink");
		
		ArrayList<String>C2=new ArrayList<String>();
		C2.add("Red");
		C2.add("Green");
		C2.add("Black");
		C2.add("Pink");
		
		ArrayList<String>C3=new ArrayList<String>();
		for (String e:C1)
			C3.add(C2.contains(e)? "Yes":"No");
		System.out.println(C3);

	}

}
